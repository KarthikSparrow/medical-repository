package com.jaicreative.trgmvc;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.jaicreative.trgmvc.model.User;
import com.jaicreative.trgmvc.service.UserService;
import com.jaicreative.trgmvc.validator.UserFormValidator;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	@Autowired(required=true)
	UserService userService;
	
	@Autowired(required=true)
	private UserFormValidator userFormValidator;
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	
	 @InitBinder
	 
	     private void initBinder(WebDataBinder binder) {
	
	         binder.setValidator(userFormValidator);
	 
	     }

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String register(Map<String, Object> model)
	{
		User user=new User();
		model.put("userForm",user);
		logger.info("In registration method()");
		return "register";
		
	}
	
	@RequestMapping(value = "/insert", method = RequestMethod.GET)
	public String insert(@Valid @ModelAttribute("userForm") User user,
            BindingResult result, Map<String, Object> model)
	{
		logger.info("In Insert method()");
		
		if (result.hasErrors()) {
            return "register";
        }
		userService.insertData(user);
		return "register";
		
	}
	@RequestMapping(value = "/listUsers", method = RequestMethod.GET)
	public String listUsers(Model model) {
		model.addAttribute("person", new User());
		model.addAttribute("listUsers", this.userService.listPersons());
		return "listUsers";
	}
	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public ModelAndView  getPersonById(@PathVariable("id") int id, Model model) {
		 model.addAttribute("person", this.userService.getUserById(id));
		 return new ModelAndView("updateUser", "command", new User());
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String updateDiary(@ModelAttribute("command") User users, ModelMap model) {
	
		userService.updateData(users);
		/*model.addAttribute("users", this.);*/
return "home";
	/*	return new ModelAndView("listusers", "command", new User());*/
	}
	@RequestMapping(value = "/remove/{id}", method = RequestMethod.GET)
	public String DeleteUser(@PathVariable("id") int id,Model model) {
		userService.deleteData(id);
		model.addAttribute("person", new User());
		model.addAttribute("listUsers", this.userService.listPersons());
		return "listUsers";
	}
	
	
}