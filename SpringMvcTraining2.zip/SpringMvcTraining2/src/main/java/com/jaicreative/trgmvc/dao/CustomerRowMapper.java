package com.jaicreative.trgmvc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.jaicreative.trgmvc.model.User;

public class CustomerRowMapper implements RowMapper{

	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		User users=new User();
		users.setId(rs.getInt("id"));
		users.setFirstName(rs.getString("firstName"));
		users.setLastName(rs.getString("lastName"));
		
		return users;
	}

}
