package com.jaicreative.trgmvc.dao;

import java.util.List;

import com.jaicreative.trgmvc.model.User;

public interface UserDao {
	 public void insertData(User user);
	 public List<User> listPersons();
	 public User getUserById(int id);
	 public void updateData(User user);
	 public void deleteData(int id);
	 
}
