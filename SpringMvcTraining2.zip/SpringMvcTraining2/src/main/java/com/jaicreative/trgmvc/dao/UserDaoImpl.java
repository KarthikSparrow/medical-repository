package com.jaicreative.trgmvc.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.jaicreative.trgmvc.model.User;
@Repository
public class UserDaoImpl implements UserDao {
@Autowired
	JdbcTemplate jdbcTemplate;
	@Override
	
	public void insertData(User user) {
		// TODO Auto-generated method stub
		String SQL = "insert into User (firstName,lastName) values (?, ?)";
		jdbcTemplate.update( SQL, new Object[]{user.getFirstName(),user.getLastName()} );
		
	}
	@Override
	public List<User> listPersons() {
		// TODO Auto-generated method stub
		
		String SQL = "select * from User";
		List<User> users  = jdbcTemplate.query(SQL,
				new BeanPropertyRowMapper(User.class));
			
		return users;
	}
	@Override
	public User getUserById(int id) {
		// TODO Auto-generated method stub
		
		System.out.println(id);
		String sql = "SELECT id,firstName,lastName FROM User  WHERE id = ?";
		User users = jdbcTemplate.queryForObject(
				sql, new Object[] { id }, new CustomerRowMapper());
			
		return users;
	}
	@Override
	public void updateData(User user) {
		// TODO Auto-generated method stub
		String fname=user.getFirstName();
		System.out.println(fname);
		String lname=user.getLastName();
		System.out.println(lname);
		int userId=user.getId();
		System.out.println(userId);
		String SQL = "UPDATE User set firstName=?,lastName=? where id=?";
		jdbcTemplate.update( SQL, new Object[]{user.getFirstName(),user.getLastName(),user.getId()} );
	}
	@Override
	public void deleteData(int id) {
		// TODO Auto-generated method stub
		String SQL = "DELETE FROM User WHERE id = ?";
		jdbcTemplate.update(SQL,id);
	}
	
}
