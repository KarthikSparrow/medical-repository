package com.jaicreative.trgmvc.service;

import java.util.List;

import com.jaicreative.trgmvc.model.User;

public interface UserService {
	 public void insertData(User user);
	 public List<User> listPersons();
	 public User getUserById(int id);
	 public void updateData(User user);
	 public void deleteData(int id);
}
