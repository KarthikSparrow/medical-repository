package com.jaicreative.trgmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jaicreative.trgmvc.dao.UserDao;
import com.jaicreative.trgmvc.model.User;
@Service
public class UserServiceImpl implements UserService {
@Autowired
	UserDao userDao;
	@Override
	@Transactional
	public void insertData(User user) {
		// TODO Auto-generated method stub
		userDao.insertData(user);
	}
	@Override
	@Transactional
	public List<User> listPersons() {
		// TODO Auto-generated method stub
		return this.userDao.listPersons();
	}
	@Override
	@Transactional
	public User getUserById(int id) {
		// TODO Auto-generated method stub
		return  this.userDao.getUserById(id);
	}
	@Override
	@Transactional
	public void updateData(User user) {
		// TODO Auto-generated method stub
		userDao.updateData(user);
	}
	@Override
	@Transactional
	public void deleteData(int id) {
		// TODO Auto-generated method stub
		userDao.deleteData(id);
	}

}
