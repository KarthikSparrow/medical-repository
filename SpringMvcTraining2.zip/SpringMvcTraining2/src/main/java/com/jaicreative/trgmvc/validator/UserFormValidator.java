package com.jaicreative.trgmvc.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.jaicreative.trgmvc.model.User;
@Component
public class UserFormValidator implements Validator{

	public boolean supports(Class<?> clazz) {
		
		return User.class.equals(clazz);
	}

	public void validate(Object obj, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,"firstName","firstName.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,"lastName","lastName.required");
		
	}

}
